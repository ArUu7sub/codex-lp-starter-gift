# Codex LP制作スターター 2ファイル版

CodexでLP制作を始めるための2つのMarkdownです。Skillの設置や、5項目を一括入力するフォームは必要ありません。

## 使い方

1. LPを制作する作業フォルダをCodexへ指定する
2. `assets/セットアップ.md` をCodexへ送る
3. 読み取り専用の確認結果と `[LP_STARTER_STATE: SETUP_READY]` を受け取り、`assets/lp実装.md` をCodexへ送る
4. LPの対象、CTA、内容、ブランド、デザインについて対話する
5. 構成、wireframe、visual direction、検証計画を明示承認した後、CodexがHTML/CSS/JSをレスポンシブ実装する
6. Codexがローカルpreviewを起動・確認し、利用者はpreview URL、検証結果、残課題を受け取る

Step 4からStep 5へ進むには、構成、wireframe、visual direction、変更予定file、検証計画への明示承認が必要です。

順番を入れ替えないでください。`lp実装.md` は、直前のassistant応答に作業フォルダの絶対パスと状態マーカーがある場合だけ開始します。

## 配布ファイル

- `assets/セットアップ.md` — 作業フォルダと既存状態を読み取り専用で確認
- `assets/lp実装.md` — 対話、実装前プラン、承認、実装、検証、Codexによるローカル確認

## 任意の補助ファイル

- `SKILL.md` と `agents/openai.yaml` は互換性のための任意補助です。標準手順や公開導線の前提ではありません。
- `references/lp-quality-checklist.md` は実装品質を確認する補助資料です。

## 境界

- この配布物は編集可能なLP初稿とCodexによるローカル確認までを支援します。利用者自身がserver起動commandを実行する必要はありません。
- 外部公開、domain、本番設定、決済、analytics、実送信フォーム接続は行いません。
- 事実、価格、実績、資格、口コミ、期限、希少性、法的結論を創作しません。
- 実装開始は、構成・wireframe・visual directionを確認した後の明示承認が必要です。

Version: `2.0.1`
