---
name: codex-lp-starter
description: Optional compatibility helper for the two-file Codex LP workflow. The supported public flow is to send assets/セットアップ.md and then assets/lp実装.md; Skill installation is not required.
metadata:
  version: "2.0.1"
---

# Codex LP制作スターター（任意補助）

このSkillは互換性のために残す任意の補助資料です。公開される標準手順はSkill設置を必要としません。

標準手順では、LP用の作業フォルダをCodexへ指定し、次のファイルを順番に送ってください。

1. [assets/セットアップ.md](assets/セットアップ.md)
2. Codexから `[LP_STARTER_STATE: SETUP_READY]` を含む完了応答を受け取る
3. [assets/lp実装.md](assets/lp実装.md)

以降の対話、実装前承認、実装、検証、ローカル確認は `lp実装.md` の指示に従います。5項目の一括入力は不要です。
