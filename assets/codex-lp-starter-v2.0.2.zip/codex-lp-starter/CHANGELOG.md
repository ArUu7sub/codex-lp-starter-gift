# Changelog

## 2.0.2 — 2026-09-25

- 利用可能なVault LP制作スキルを名前付き工程として実際に起動し、利用不可時はfallbackを記録する仕様を追加
- `wireframe-designer`をvisual direction前の必須工程とし、mobile／desktop、Header、Hero、CTA、Footerのwireframe要件を追加
- Heroを全面の生成背景とcode-based textに統一し、左テキスト・右被写体と中央テキストの2patternを定義
- Hero背景を実際に生成・選定・local assetへ保存し、responsive cropを確認する完了条件を追加
- 固定Header、mobile hamburger menu、Headerと対応するFooter、およびresponsive・accessibility検証を追加

## 2.0.1 — 2026-09-25

- LPのローカルpreviewはCodex自身が起動・確認する運用へ統一
- 利用者へserver起動commandの実行を求めない境界を追加
- 実行環境の制約がある場合は、代行実行を依頼せず未確認項目を明示する仕様へ変更

## 2.0.0 — 2026-09-25

- LP制作を、Skill設置と5項目一括入力から2つのMarkdownを順番に使う方式へ変更
- `assets/セットアップ.md` に読み取り専用の作業フォルダ確認を分離
- `assets/lp実装.md` に対話、実装前承認、HTML/CSS/JS実装、検証、ローカル確認を統合
- 明示承認前の書込み禁止、状態マーカー、mobile-first、creative reviewの境界を追加
- `SKILL.md` を任意の補助資料へ変更し、利用の前提から除外
- 旧5項目テンプレートを配布物から削除

## 1.0.0 — 2026-09-25

- Codex向けのLP制作フローを追加
- 5項目の依頼テンプレートを追加
- 事実の創作防止、既存変更の保護、外部公開の権限境界を明文化
- コピー、レスポンシブ、アクセシビリティ、実装の確認項目を追加
